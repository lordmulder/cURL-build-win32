/* SPDX-License-Identifier: CC0-1.0 */

extern int main(int argc, char *argv[]);

int wmain(void) {
	char *args[] = { "a.exe", (void*)0 };
	return main(1, (char**)args);
}
